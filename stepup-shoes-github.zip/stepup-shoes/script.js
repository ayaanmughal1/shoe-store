const products = [
  {id:1,name:"Street Runner 01",category:"sneakers",label:"BEST SELLER",price:7499,rating:"4.9",reviews:128,color:"Red / White",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"},
  {id:2,name:"Cloud Pace",category:"running",label:"NEW DROP",price:8999,rating:"4.8",reviews:86,color:"White / Grey",image:"https://images.unsplash.com/photo-1552674605-db6ffd4facb5?auto=format&fit=crop&w=800&q=80"},
  {id:3,name:"Retro Court",category:"casual",label:"EVERYDAY",price:6299,rating:"4.7",reviews:94,color:"White / Green",image:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=800&q=80"},
  {id:4,name:"Urban Classic",category:"sneakers",label:"POPULAR",price:6999,rating:"4.8",reviews:112,color:"Black / White",image:"https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?auto=format&fit=crop&w=800&q=80"},
  {id:5,name:"Motion Flex",category:"running",label:"LIGHTWEIGHT",price:8299,rating:"4.9",reviews:73,color:"Grey / Orange",image:"https://images.unsplash.com/photo-1460353581641-37b栈?auto=format&fit=crop&w=800&q=80"},
  {id:6,name:"Daily Low Top",category:"casual",label:"EASY WEAR",price:5499,rating:"4.6",reviews:61,color:"Cream / Tan",image:"https://images.unsplash.com/photo-1495555961986-6d4c1ecb7be3?auto=format&fit=crop&w=800&q=80"},
  {id:7,name:"Fast Lane",category:"running",label:"PERFORMANCE",price:9499,rating:"4.8",reviews:49,color:"Black / Red",image:"https://images.unsplash.com/photo-1538805060514-97d9cc17730c?auto=format&fit=crop&w=800&q=80"},
  {id:8,name:"Canvas Move",category:"sneakers",label:"JUST IN",price:4999,rating:"4.7",reviews:58,color:"Black / White",image:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=800&q=80"}
];
const money = amount => "Rs. " + amount.toLocaleString("en-PK");
const productsEl = document.getElementById("products");
const cartCountEl = document.getElementById("cartCount");
const cartHeadingCount = document.getElementById("cartHeadingCount");
const cartItemsEl = document.getElementById("cartItems");
const cartTotalEl = document.getElementById("cartTotal");
const toastEl = document.getElementById("toast");
let activeFilter = "all";
let cart = JSON.parse(localStorage.getItem("stepup-cart") || "[]");
let wishlist = JSON.parse(localStorage.getItem("stepup-wishlist") || "[]");
let toastTimer;

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2200);
}
function renderProducts() {
  const query = document.getElementById("searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p => (activeFilter === "all" || p.category === activeFilter) && `${p.name} ${p.category} ${p.color}`.toLowerCase().includes(query));
  if (!filtered.length) {
    productsEl.innerHTML = '<div class="no-results">No shoes found. Try another search or category.</div>';
    return;
  }
  productsEl.innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-image-wrap">
        <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80'">
        <span class="product-tag">${p.label}</span>
        <button class="wishlist-button ${wishlist.includes(p.id) ? "saved" : ""}" data-wishlist="${p.id}" aria-label="${wishlist.includes(p.id) ? "Remove from" : "Add to"} wishlist">${wishlist.includes(p.id) ? "♥" : "♡"}</button>
      </div>
      <div class="product-info">
        <div class="product-meta"><div><h3 class="product-name">${p.name}</h3><span class="product-category">${p.category[0].toUpperCase()+p.category.slice(1)} · ${p.color}</span></div><span class="product-price">${money(p.price)}</span></div>
        <div class="product-rating"><span class="stars">★★★★★</span> &nbsp;${p.rating} (${p.reviews})</div>
        <button class="add-button" data-add="${p.id}">ADD TO BAG +</button>
      </div>
    </article>`).join("");
}
function saveCart() { localStorage.setItem("stepup-cart", JSON.stringify(cart)); renderCart(); }
function addToCart(id) {
  const existing = cart.find(item => item.id === id);
  if (existing) existing.qty += 1;
  else cart.push({id, qty:1});
  saveCart();
  showToast(`${products.find(p=>p.id===id).name} added to your bag`);
}
function renderCart() {
  const count = cart.reduce((sum,item)=>sum+item.qty,0);
  cartCountEl.textContent = count;
  cartHeadingCount.textContent = `(${count})`;
  const total = cart.reduce((sum,item)=>sum+products.find(p=>p.id===item.id).price*item.qty,0);
  cartTotalEl.textContent = money(total);
  if (!cart.length) {
    cartItemsEl.innerHTML = '<div class="empty-cart">Your bag is looking a little light. ✳<br><span>Find something you love.</span></div>';
    return;
  }
  cartItemsEl.innerHTML = cart.map(item => {
    const p = products.find(product=>product.id===item.id);
    return `<div class="cart-item"><img src="${p.image}" alt=""><div><strong>${p.name}</strong><small>${p.color}</small><div class="quantity-controls"><button data-qty="${p.id}" data-change="-1" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-change="1" aria-label="Increase quantity">+</button></div><button class="remove-item" data-remove="${p.id}">Remove</button></div><span class="cart-item-price">${money(p.price*item.qty)}</span></div>`;
  }).join("");
}
function openCart() {
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("overlay").classList.add("open");
  document.getElementById("cartDrawer").setAttribute("aria-hidden","false");
  document.body.style.overflow = "hidden";
}
function closeCart() {
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("open");
  document.getElementById("cartDrawer").setAttribute("aria-hidden","true");
  document.body.style.overflow = "";
}
productsEl.addEventListener("click", e => {
  const add = e.target.closest("[data-add]");
  const wish = e.target.closest("[data-wishlist]");
  if (add) addToCart(Number(add.dataset.add));
  if (wish) {
    const id = Number(wish.dataset.wishlist);
    wishlist = wishlist.includes(id) ? wishlist.filter(x=>x!==id) : [...wishlist,id];
    localStorage.setItem("stepup-wishlist",JSON.stringify(wishlist));
    renderProducts();
    showToast(wishlist.includes(id) ? "Saved to your wishlist" : "Removed from your wishlist");
  }
});
document.getElementById("filters").addEventListener("click", e => {
  const button = e.target.closest("[data-filter]");
  if (!button) return;
  activeFilter = button.dataset.filter;
  document.querySelectorAll(".filter-pill").forEach(b=>b.classList.toggle("active",b===button));
  renderProducts();
});
document.getElementById("searchInput").addEventListener("input",renderProducts);
cartItemsEl.addEventListener("click",e=>{
  const qty = e.target.closest("[data-qty]");
  const remove = e.target.closest("[data-remove]");
  if (qty) {
    const item=cart.find(i=>i.id===Number(qty.dataset.qty));
    item.qty += Number(qty.dataset.change);
    if(item.qty<=0) cart=cart.filter(i=>i.id!==item.id);
    saveCart();
  }
  if(remove){cart=cart.filter(i=>i.id!==Number(remove.dataset.remove));saveCart();}
});
document.getElementById("cartOpen").addEventListener("click",openCart);
document.getElementById("cartClose").addEventListener("click",closeCart);
document.getElementById("overlay").addEventListener("click",closeCart);
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeCart();});
document.getElementById("checkoutButton").addEventListener("click",()=>{
  document.getElementById("checkoutMessage").textContent = cart.length ? "Demo checkout only. Connect a secure backend/payment provider to accept orders." : "Add a pair to your bag before checkout.";
  showToast(cart.length ? "Demo store: checkout is not connected yet" : "Your bag is empty");
});
document.getElementById("themeToggle").addEventListener("click",()=>{
  const themes=["orange","blue","purple","green"];
  const current=document.documentElement.dataset.theme || "orange";
  const next=themes[(themes.indexOf(current)+1)%themes.length];
  if(next==="orange") delete document.documentElement.dataset.theme;
  else document.documentElement.dataset.theme=next;
  localStorage.setItem("stepup-theme",next);
  showToast(`${next[0].toUpperCase()+next.slice(1)} theme`);
});
const savedTheme=localStorage.getItem("stepup-theme");
if(savedTheme && savedTheme!=="orange") document.documentElement.dataset.theme=savedTheme;
document.getElementById("menuToggle").addEventListener("click",()=>{
  const nav=document.getElementById("nav");
  const opened=nav.classList.toggle("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded",String(opened));
});
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>{
  document.getElementById("nav").classList.remove("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded","false");
}));
document.querySelectorAll("[data-collection]").forEach(a=>a.addEventListener("click",()=>{
  activeFilter=a.dataset.collection;
  document.querySelectorAll(".filter-pill").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));
  renderProducts();
}));
document.getElementById("newsletterForm").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("newsletterMessage").textContent="Thanks! This demo form does not store or send email addresses.";
  e.target.reset();
});
renderProducts();
renderCart();
