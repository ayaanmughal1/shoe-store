# STEPUP SHOES 👟

A responsive, colorful shoe-store demo built with HTML, CSS, and vanilla JavaScript. It is designed to upload directly to GitHub and publish using GitHub Pages.

## Features
- Responsive layout for desktop, tablet, and mobile
- Four switchable themes: orange, blue, purple, and green
- Product search and category filters
- Shopping bag with quantity controls and subtotal
- Wishlist saved in the browser
- Newsletter demo form and responsive mobile navigation
- Local storage remembers cart, wishlist, and theme

## Run locally
Open `index.html` in your browser. No build step or package installation is needed.

## Publish with GitHub Pages
1. Create a new repository on GitHub (for example, `stepup-shoes`).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)` folder, then click **Save**.
6. Wait a few minutes and open the URL GitHub Pages provides.

## Important notes
- Product images are loaded from Unsplash, so the browser needs an internet connection to display them.
- Product names, prices, ratings, and stock are demo content. Change them in `script.js`.
- The checkout is intentionally a demo. It does not process payments or send orders.
- The newsletter form does not collect or send emails.
- A real online shop needs a secure backend, inventory/order handling, and a payment provider.
